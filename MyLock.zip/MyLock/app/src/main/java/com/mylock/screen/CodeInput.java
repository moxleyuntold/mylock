package com.mylock.screen;

import android.view.View;

/** A PIN pad or pattern grid. onCode gets the entered code, or null if it was too short. */
interface CodeInput {
    interface OnCode { void onCode(String code); }
    View getView();
    void reset();
}
