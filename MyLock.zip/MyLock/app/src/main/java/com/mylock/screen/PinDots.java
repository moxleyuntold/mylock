package com.mylock.screen;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** Row of dots showing how many digits are typed. Empty rings hint at the 4-digit minimum. */
final class PinDots extends View {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int count;
    private boolean warn;

    PinDots(Context c) {
        super(c);
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(Ui.dp(c, 1.4f));
    }

    void setCount(int n) { count = n; invalidate(); }

    void setWarn(boolean w) { warn = w; invalidate(); }

    @Override protected void onDraw(Canvas c) {
        int slots = Math.max(4, count);
        float gap = Ui.dp(getContext(), 22), r = Ui.dp(getContext(), 5.5f);
        float x0 = (getWidth() - (slots - 1) * gap) / 2f, y = getHeight() / 2f;
        int on = warn ? Theme.WARN : Theme.TEXT;
        fill.setColor(on);
        ring.setColor(warn ? Theme.WARN : 0x66F4F6F8);
        for (int i = 0; i < slots; i++) {
            if (i < count) c.drawCircle(x0 + i * gap, y, r, fill);
            else c.drawCircle(x0 + i * gap, y, r, ring);
        }
    }
}
