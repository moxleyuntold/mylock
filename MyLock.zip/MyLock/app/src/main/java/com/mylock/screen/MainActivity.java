package com.mylock.screen;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private SharedPreferences sp;
    private TextView status, lockStatus;
    private Button toggle;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("prefs", Context.MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setBackgroundColor(Color.BLACK);
        int p = dp(24);
        col.setPadding(p, dp(56), p, p);

        TextView title = new TextView(this);
        title.setText("My Lock");
        title.setTextColor(Color.parseColor("#E5261F"));
        title.setTextSize(40);
        title.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        col.addView(title);

        status = new TextView(this);
        status.setTextColor(Color.parseColor("#F3ECE6"));
        status.setTextSize(16);
        status.setPadding(0, dp(12), 0, dp(24));
        col.addView(status);

        col.addView(button("Allow display over other apps", v -> openOverlaySettings()));

        toggle = button("", v -> {
            if (!Settings.canDrawOverlays(this)) { openOverlaySettings(); return; }
            boolean on = !sp.getBoolean("on", false);
            sp.edit().putBoolean("on", on).apply();
            Intent svc = new Intent(this, LockService.class);
            if (on) startForegroundService(svc); else stopService(svc);
            refresh();
        });
        col.addView(toggle);

        lockStatus = new TextView(this);
        lockStatus.setTextColor(Color.parseColor("#F3ECE6"));
        lockStatus.setTextSize(16);
        lockStatus.setPadding(0, dp(24), 0, 0);
        col.addView(lockStatus);
        col.addView(button("Set PIN", v -> openSetup("pin")));
        col.addView(button("Set pattern", v -> openSetup("pattern")));
        col.addView(button("Remove PIN / pattern", v -> openSetup("remove")));

        col.addView(button("Preview lock screen", v -> LockService.showLock(this)));
        col.addView(button("Keep running in background (battery)", v ->
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))));

        TextView tip = new TextView(this);
        tip.setTextColor(Color.parseColor("#99F3ECE6"));
        tip.setTextSize(13);
        tip.setPadding(0, dp(20), 0, 0);
        tip.setText("Vivo tip: also allow Auto-start and Background running for My Lock in "
                + "Settings > Apps > My Lock, or the lock screen may stop after a while.");
        col.addView(tip);

        setContentView(col);
    }

    private void openSetup(String mode) {
        startActivity(new Intent(this, SetupLockActivity.class).putExtra("mode", mode));
    }

    private void openOverlaySettings() {
        startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName())));
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    private void refresh() {
        boolean can = Settings.canDrawOverlays(this);
        boolean on = sp.getBoolean("on", false);
        status.setText(!can ? "Step 1: allow display over other apps."
                : on ? "Lock screen is ON. Turn the screen off and on to see it."
                : "Ready. Turn on the lock screen below.");
        String t = LockStore.type(this);
        lockStatus.setText("App lock: " + (t.equals(LockStore.PIN) ? "PIN"
                : t.equals(LockStore.PATTERN) ? "Pattern" : "Off"));
        toggle.setText(on ? "Turn lock screen off" : "Turn lock screen on");
    }

    private Button button(String text, View.OnClickListener l) {
        Button bt = new Button(this);
        bt.setText(text);
        bt.setAllCaps(false);
        bt.setTextColor(Color.parseColor("#F3ECE6"));
        bt.setBackgroundColor(Color.parseColor("#2A0A09"));
        bt.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52));
        lp.topMargin = dp(10);
        bt.setLayoutParams(lp);
        return bt;
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }
}
