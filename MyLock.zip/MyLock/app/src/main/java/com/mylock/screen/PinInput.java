package com.mylock.screen;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Numeric keypad: 4 to 8 digits, tap the tick to confirm. */
public class PinInput extends LinearLayout implements CodeInput {
    private final StringBuilder sb = new StringBuilder();
    private final TextView dots;
    private final OnCode cb;

    public PinInput(Context c, OnCode cb) {
        super(c);
        this.cb = cb;
        setOrientation(VERTICAL);
        setGravity(Gravity.CENTER_HORIZONTAL);

        dots = new TextView(c);
        dots.setTextColor(Color.parseColor("#F3ECE6"));
        dots.setTextSize(26);
        dots.setGravity(Gravity.CENTER);
        addView(dots, new LayoutParams(LayoutParams.MATCH_PARENT, LockUi.dp(c, 56)));

        String[] keys = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "\u232B", "0", "\u2713"};
        for (int r = 0; r < 4; r++) {
            LinearLayout row = new LinearLayout(c);
            row.setGravity(Gravity.CENTER);
            for (int k = 0; k < 3; k++) {
                final String key = keys[r * 3 + k];
                TextView t = new TextView(c);
                t.setText(key);
                t.setTextSize(24);
                t.setGravity(Gravity.CENTER);
                t.setTextColor(Color.parseColor(key.equals("\u2713") ? "#E5261F" : "#F3ECE6"));
                GradientDrawable g = new GradientDrawable();
                g.setShape(GradientDrawable.OVAL);
                g.setColor(Color.parseColor("#26FFFFFF"));
                t.setBackground(g);
                t.setOnClickListener(v -> press(key));
                LayoutParams lp = new LayoutParams(LockUi.dp(c, 72), LockUi.dp(c, 72));
                lp.setMargins(LockUi.dp(c, 10), LockUi.dp(c, 6), LockUi.dp(c, 10), LockUi.dp(c, 6));
                row.addView(t, lp);
            }
            addView(row);
        }
        update();
    }

    private void press(String key) {
        if (key.equals("\u232B")) {
            if (sb.length() > 0) sb.deleteCharAt(sb.length() - 1);
        } else if (key.equals("\u2713")) {
            String code = sb.length() >= 4 ? sb.toString() : null;
            cb.onCode(code);
            return;
        } else if (sb.length() < 8) {
            sb.append(key);
        }
        update();
    }

    private void update() {
        StringBuilder d = new StringBuilder();
        for (int i = 0; i < sb.length(); i++) d.append("\u25CF ");
        dots.setText(d.length() == 0 ? " " : d.toString().trim());
    }

    @Override public View getView() { return this; }

    @Override public void reset() { sb.setLength(0); update(); }
}
