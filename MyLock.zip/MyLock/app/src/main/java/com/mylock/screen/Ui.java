package com.mylock.screen;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

/** Small helpers so every screen shares the same glossy, minimal look. */
final class Ui {
    private Ui() { }

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static float sp(Context c, float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, c.getResources().getDisplayMetrics());
    }

    /** Centered single-style text label. */
    static TextView label(Context c, float sizeSp, int color, boolean caps, String family) {
        TextView t = new TextView(c);
        t.setTextSize(sizeSp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setIncludeFontPadding(false);
        t.setAllCaps(caps);
        t.setTypeface(Typeface.create(family, Typeface.NORMAL));
        return t;
    }

    private static GradientDrawable glass(Context c, boolean oval, float radiusDp, int top, int bottom, int stroke) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{top, bottom});
        g.setShape(oval ? GradientDrawable.OVAL : GradientDrawable.RECTANGLE);
        if (!oval) g.setCornerRadius(dp(c, radiusDp));
        g.setStroke(dp(c, 1), stroke);
        return g;
    }

    /** Frosted circle used for keypad keys. */
    static Drawable glassKey(Context c) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed},
                glass(c, true, 0, 0x59FFFFFF, 0x33FFFFFF, 0x4DFFFFFF));
        s.addState(new int[]{}, glass(c, true, 0, 0x33FFFFFF, 0x0DFFFFFF, 0x29FFFFFF));
        return s;
    }

    /** Frosted circle with an accent tint (confirm key). */
    static Drawable accentKey(Context c) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed},
                glass(c, true, 0, 0x807FD8DC, 0x407FD8DC, 0xB37FD8DC));
        s.addState(new int[]{}, glass(c, true, 0, 0x407FD8DC, 0x147FD8DC, 0x807FD8DC));
        return s;
    }

    /** Frosted rounded button for the settings screen. */
    static Drawable glassPill(Context c) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed},
                glass(c, false, 26, 0x59FFFFFF, 0x33FFFFFF, 0x4DFFFFFF));
        s.addState(new int[]{}, glass(c, false, 26, 0x2EFFFFFF, 0x0DFFFFFF, 0x29FFFFFF));
        return s;
    }

    static Drawable accentPill(Context c) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFFA5EAED, 0xFF6CC7CC});
        g.setCornerRadius(dp(c, 26));
        return g;
    }

    static Drawable screenBackground() {
        return new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Theme.BG, Theme.BG2});
    }

    /** Gentle press-in feel. Returns false so normal click handling still runs. */
    static void pressable(View v) {
        v.setOnTouchListener((view, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    view.animate().scaleX(0.92f).scaleY(0.92f).setDuration(70).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    view.animate().scaleX(1f).scaleY(1f).setDuration(140).start();
                    break;
            }
            return false;
        });
    }

    static void shake(View v) {
        float d = dp(v.getContext(), 10);
        ObjectAnimator a = ObjectAnimator.ofFloat(v, "translationX", 0, -d, d, -d * 0.6f, d * 0.6f, 0);
        a.setDuration(320);
        a.start();
    }
}
