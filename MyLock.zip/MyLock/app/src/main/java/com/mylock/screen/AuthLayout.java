package com.mylock.screen;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Shared, centred layout for entering a PIN or pattern (lock screen and setup). */
final class AuthLayout extends LinearLayout {
    private final TextView title, msg;
    private final FrameLayout holder;
    private final LinearLayout links;
    private CodeInput input;

    AuthLayout(Context c) {
        super(c);
        setOrientation(VERTICAL);
        setGravity(Gravity.CENTER);

        title = Ui.label(c, 12, Theme.MUTED, true, "sans-serif-medium");
        title.setLetterSpacing(0.26f);
        addView(title, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        msg = Ui.label(c, 13, Theme.MUTED, false, "sans-serif");
        LayoutParams mp = new LayoutParams(LayoutParams.MATCH_PARENT, Ui.dp(c, 24));
        mp.topMargin = Ui.dp(c, 10);
        mp.bottomMargin = Ui.dp(c, 14);
        addView(msg, mp);

        holder = new FrameLayout(c);
        addView(holder, new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));

        links = new LinearLayout(c);
        links.setGravity(Gravity.CENTER);
        LayoutParams lp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(c, 12);
        addView(links, lp);
    }

    void setTitle(String s) { title.setText(s); }

    void setMessage(String s, boolean warn) {
        msg.setText(s);
        msg.setTextColor(warn ? Theme.WARN : Theme.MUTED);
    }

    void setInput(CodeInput in) {
        input = in;
        holder.removeAllViews();
        View v = in.getView();
        int w = (v instanceof PatternView) ? Ui.dp(getContext(), 300) : LayoutParams.WRAP_CONTENT;
        int h = (v instanceof PatternView) ? Ui.dp(getContext(), 300) : LayoutParams.WRAP_CONTENT;
        holder.addView(v, new FrameLayout.LayoutParams(w, h, Gravity.CENTER));
    }

    CodeInput input() { return input; }

    void addLink(String label, View.OnClickListener l) {
        TextView t = Ui.label(getContext(), 14, Theme.MUTED, false, "sans-serif-medium");
        t.setText(label);
        int hp = Ui.dp(getContext(), 22), vp = Ui.dp(getContext(), 12);
        t.setPadding(hp, vp, hp, vp);
        t.setOnClickListener(l);
        links.addView(t);
    }
}
