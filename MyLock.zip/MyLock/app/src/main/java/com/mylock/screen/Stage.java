package com.mylock.screen;

import android.content.Context;
import android.view.View;
import android.widget.FrameLayout;

/**
 * Fixed-shape canvas (same shape as the wallpaper) so the clock digits always line up
 * with the character, whatever the screen size. Extra height is cropped from the top.
 */
final class Stage extends FrameLayout {
    static final float ASPECT = 2340f / 1080f;

    Stage(Context c) { super(c); }

    @Override protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec);
        int h = Math.round(w * ASPECT);
        int cw = MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY);
        int ch = MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY);
        for (int i = 0; i < getChildCount(); i++) {
            View v = getChildAt(i);
            if (v.getVisibility() != GONE) v.measure(cw, ch);
        }
        setMeasuredDimension(w, h);
    }
}
