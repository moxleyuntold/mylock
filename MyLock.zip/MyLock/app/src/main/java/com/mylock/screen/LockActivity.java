package com.mylock.screen;

import android.app.Activity;
import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.text.format.DateFormat;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class LockActivity extends Activity {
    private static volatile boolean alive = false;
    private static int fails = 0;
    private static long lockedUntil = 0;

    static boolean isAlive() { return alive; }

    private FrameLayout root;
    private Stage stage;
    private ClockView hourV, minV, infoV;
    private ImageView subV;
    private View[] layers;
    private final float[] speed = {0.30f, 0.45f, 0.45f, 0.20f};
    private LinearLayout bar;
    private ImageButton flashBtn;

    private CameraManager cm;
    private CameraManager.TorchCallback torchCb;
    private String flashId;
    private boolean torchOn = false;

    private boolean unlocked = false, leaving = false;
    private int battery = -1;
    private float downY;

    private FrameLayout panel;
    private AuthLayout auth;

    // ------------------------------------------------------------------ setup

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        alive = true;
        setShowWhenLocked(true); // shows above the phone's lock; never turns the display on

        buildUi();
        setupTorch();
        setupTouch();
    }

    private ImageView layer(Bitmap bmp) {
        ImageView iv = new ImageView(this);
        iv.setImageBitmap(bmp);
        iv.setScaleType(ImageView.ScaleType.FIT_XY);
        return iv;
    }

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF0E0F12);

        stage = new Stage(this);
        ImageView bgV = layer(Art.bg(this));
        subV = layer(Art.subject(this));
        hourV = new ClockView(this, ClockView.HOUR);
        minV = new ClockView(this, ClockView.MIN);
        infoV = new ClockView(this, ClockView.INFO);
        FrameLayout.LayoutParams full = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
        stage.addView(bgV, full);
        stage.addView(hourV, full);   // behind the character
        stage.addView(subV, full);    // the character
        stage.addView(minV, full);    // in front of the character
        stage.addView(infoV, full);
        root.addView(stage, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM));
        layers = new View[]{hourV, subV, minV, infoV};

        // bottom row: flash - hint - camera, all on one centre line
        bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        int btn = Ui.dp(this, 56);

        flashBtn = shortcut(R.drawable.ic_flash, "Flashlight");
        flashBtn.setOnClickListener(v -> toggleTorch());
        ImageButton camBtn = shortcut(R.drawable.ic_camera, "Camera");
        camBtn.setOnClickListener(v -> openCamera());

        TextView hint = Ui.label(this, 11, 0xB3F4F6F8, true, "sans-serif-medium");
        hint.setLetterSpacing(0.22f);
        hint.setText("Swipe up to unlock");

        bar.addView(flashBtn, new LinearLayout.LayoutParams(btn, btn));
        bar.addView(hint, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        bar.addView(camBtn, new LinearLayout.LayoutParams(btn, btn));

        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, btn, Gravity.BOTTOM);
        bp.leftMargin = Ui.dp(this, 36);
        bp.rightMargin = Ui.dp(this, 36);
        bp.bottomMargin = Ui.dp(this, 44);
        root.addView(bar, bp);

        setContentView(root);
    }

    private ImageButton shortcut(int icon, String desc) {
        ImageButton ib = new ImageButton(this);
        ib.setBackgroundResource(R.drawable.btn_glass);
        ib.setImageResource(icon);
        ib.setScaleType(ImageView.ScaleType.CENTER);
        ib.setContentDescription(desc);
        ib.setColorFilter(Theme.TEXT);
        Ui.pressable(ib);
        return ib;
    }

    private void setupTorch() {
        cm = (CameraManager) getSystemService(CAMERA_SERVICE);
        try {
            for (String id : cm.getCameraIdList()) {
                CameraCharacteristics c = cm.getCameraCharacteristics(id);
                Boolean f = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                if (Boolean.TRUE.equals(f) && facing != null
                        && facing == CameraCharacteristics.LENS_FACING_BACK) { flashId = id; break; }
            }
        } catch (Exception ignored) { }
        torchCb = new CameraManager.TorchCallback() {
            @Override public void onTorchModeChanged(String id, boolean enabled) {
                if (id.equals(flashId)) {
                    torchOn = enabled;
                    flashBtn.setSelected(enabled);
                    flashBtn.setColorFilter(enabled ? Theme.BG : Theme.TEXT);
                }
            }
        };
        cm.registerTorchCallback(torchCb, null);
    }

    private void setupTouch() {
        root.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downY = e.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    applyDrag(Math.max(0, downY - e.getRawY()));
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL: {
                    float d = downY - e.getRawY();
                    if (e.getActionMasked() == MotionEvent.ACTION_UP && d > root.getHeight() * 0.18f) {
                        onSwipeUp();
                    } else {
                        restoreLayers();
                    }
                    return true;
                }
            }
            return false;
        });
    }

    // -------------------------------------------------------------- animation

    private void applyDrag(float d) {
        float a = Math.max(0.25f, 1f - (d / root.getHeight()) * 1.6f);
        for (int i = 0; i < layers.length; i++) {
            layers[i].setTranslationY(-d * speed[i]);
            layers[i].setAlpha(a);
        }
        bar.setAlpha(a);
    }

    private void restoreLayers() {
        DecelerateInterpolator di = new DecelerateInterpolator();
        for (View v : layers) v.animate().translationY(0).alpha(1f).setDuration(200).setInterpolator(di).start();
        bar.animate().alpha(1f).setDuration(200).start();
    }

    /** Small entrance animation each time the lock screen appears. */
    private void playIntro() {
        DecelerateInterpolator di = new DecelerateInterpolator(1.6f);
        float rise = Ui.dp(this, 26);
        View[] order = {hourV, minV, infoV, bar};
        for (int i = 0; i < order.length; i++) {
            View v = order[i];
            v.animate().cancel();
            v.setAlpha(0f);
            v.setTranslationY(rise);
            v.animate().alpha(1f).translationY(0).setStartDelay(i * 60L).setDuration(380)
                    .setInterpolator(di).start();
        }
        subV.animate().cancel();
        subV.setTranslationY(0);
        subV.setAlpha(0f);
        subV.animate().alpha(1f).setStartDelay(0).setDuration(320).start();
    }

    // -------------------------------------------------------------- time/date

    private final BroadcastReceiver tick = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            if (Intent.ACTION_BATTERY_CHANGED.equals(i.getAction())) readBattery(i);
            refresh();
        }
    };

    private void readBattery(Intent i) {
        int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        if (level >= 0 && scale > 0) battery = level * 100 / scale;
    }

    private void refresh() {
        Calendar cal = Calendar.getInstance();
        int h = DateFormat.is24HourFormat(this) ? cal.get(Calendar.HOUR_OF_DAY)
                : (cal.get(Calendar.HOUR) == 0 ? 12 : cal.get(Calendar.HOUR));
        hourV.setText(String.format(Locale.US, "%02d", h));
        minV.setText(String.format(Locale.US, "%02d", cal.get(Calendar.MINUTE)));
        String date = new SimpleDateFormat("EEE, d MMM", Locale.getDefault())
                .format(cal.getTime()).toUpperCase(Locale.getDefault());
        infoV.setText(battery >= 0 ? date + "  \u00B7  " + battery + "%" : date);
    }

    // ---------------------------------------------------------------- unlock

    private void onSwipeUp() {
        if (LockStore.NONE.equals(LockStore.type(this))) {
            float up = root.getHeight() * 0.15f;
            AccelerateInterpolator ai = new AccelerateInterpolator();
            for (int i = 0; i < layers.length; i++) {
                layers[i].animate().translationY(-up * speed[i] * 3f).alpha(0f).setDuration(170)
                        .setInterpolator(ai).start();
            }
            bar.animate().alpha(0f).setDuration(170).withEndAction(this::finishUnlock).start();
        } else {
            for (View v : layers) v.animate().alpha(0.25f).setDuration(160).start();
            bar.animate().alpha(0f).setDuration(160).start();
            showAuth();
        }
    }

    private void showAuth() {
        if (panel != null) return;
        String type = LockStore.type(this);
        boolean pin = type.equals(LockStore.PIN);

        panel = new FrameLayout(this);
        panel.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xB80B0C10, 0xF20B0C10}));
        panel.setClickable(true);

        auth = new AuthLayout(this);
        auth.setTitle(pin ? "Enter PIN" : "Draw pattern");
        auth.setMessage("", false);
        auth.setInput(LockUi.create(this, type, this::onCode));
        KeyguardManager km = getSystemService(KeyguardManager.class);
        if (km.isKeyguardSecure()) auth.addLink("Phone PIN", v -> finishUnlock());
        auth.addLink("Cancel", v -> hideAuth());

        panel.addView(auth, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(panel);
        panel.setAlpha(0f);
        panel.animate().alpha(1f).setDuration(180).start();
    }

    private void hideAuth() {
        if (panel != null) {
            root.removeView(panel);
            panel = null;
            auth = null;
            restoreLayers();
        }
    }

    private void onCode(String code) {
        if (auth == null) return;
        boolean pin = LockStore.type(this).equals(LockStore.PIN);
        CodeInput in = auth.input();
        if (code == null) {
            auth.setMessage(pin ? "Use at least 4 digits" : "Connect at least 4 dots", true);
            in.error();
            return;
        }
        long now = SystemClock.elapsedRealtime();
        if (now < lockedUntil) {
            auth.setMessage("Too many attempts. Try again in " + ((lockedUntil - now + 999) / 1000) + "s", true);
            in.error();
            return;
        }
        if (LockStore.check(this, code)) {
            fails = 0;
            finishUnlock();
        } else {
            fails++;
            if (fails >= 5) {
                fails = 0;
                lockedUntil = now + 30000;
                auth.setMessage("Too many attempts. Wait 30 seconds.", true);
            } else {
                auth.setMessage(pin ? "Wrong PIN" : "Wrong pattern", true);
            }
            in.error();
        }
    }

    /** Also hands over to the phone's own lock if one is set. */
    private void finishUnlock() {
        KeyguardManager km = getSystemService(KeyguardManager.class);
        if (km.isKeyguardLocked()) {
            km.requestDismissKeyguard(this, new KeyguardManager.KeyguardDismissCallback() {
                @Override public void onDismissSucceeded() { unlocked = true; close(); }
                @Override public void onDismissCancelled() { hideAuth(); restoreLayers(); }
            });
        } else {
            unlocked = true;
            close();
        }
    }

    private void close() {
        finish();
        overridePendingTransition(0, 0);
    }

    // ------------------------------------------------------------- shortcuts

    private void toggleTorch() {
        if (flashId == null) {
            Toast.makeText(this, "No flash found", Toast.LENGTH_SHORT).show();
            return;
        }
        try { cm.setTorchMode(flashId, !torchOn); } catch (Exception e) {
            Toast.makeText(this, "Flash unavailable", Toast.LENGTH_SHORT).show();
        }
    }

    private void openCamera() {
        KeyguardManager km = getSystemService(KeyguardManager.class);
        String action = km.isKeyguardSecure()
                ? MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA_SECURE
                : MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA;
        leaving = true;
        try {
            startActivity(new Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            try {
                startActivity(new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Exception e2) {
                leaving = false;
                Toast.makeText(this, "Camera app not found", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // ------------------------------------------------------------- lifecycle

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        unlocked = false;
        hideAuth();
        for (View v : layers) { v.setTranslationY(0); v.setAlpha(1f); }
        bar.setAlpha(1f);
    }

    @Override protected void onStart() {
        super.onStart();
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_TIME_TICK);
        f.addAction(Intent.ACTION_TIME_CHANGED);
        f.addAction(Intent.ACTION_TIMEZONE_CHANGED);
        f.addAction(Intent.ACTION_BATTERY_CHANGED);
        Intent sticky = registerReceiver(tick, f);
        if (sticky != null) readBattery(sticky);
        refresh();
    }

    @Override protected void onResume() {
        super.onResume();
        leaving = false;
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm.isInteractive() && panel == null) playIntro();
    }

    @Override protected void onStop() {
        super.onStop();
        try { unregisterReceiver(tick); } catch (Exception ignored) { }
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        boolean on = getSharedPreferences("prefs", Context.MODE_PRIVATE).getBoolean("on", false);
        // With a PIN/pattern set, pressing Home brings the lock screen back (never while the display is off).
        if (pm.isInteractive() && !unlocked && !leaving && !isFinishing() && on
                && !LockStore.NONE.equals(LockStore.type(this))) {
            LockService.showLock(this);
        }
    }

    @Override protected void onDestroy() {
        alive = false;
        if (cm != null && torchCb != null) cm.unregisterTorchCallback(torchCb);
        super.onDestroy();
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    @Override public void onBackPressed() { hideAuth(); }
}
