package com.mylock.screen;

/** One place for the colours used across the app. */
final class Theme {
    private Theme() { }
    static final int BG = 0xFF0B0C10;
    static final int BG2 = 0xFF161B23;
    static final int TEXT = 0xFFF4F6F8;
    static final int MUTED = 0xFF8B93A0;
    static final int ACCENT = 0xFF7FD8DC;
    static final int WARN = 0xFFE5585B;
}
