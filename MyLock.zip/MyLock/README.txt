MY LOCK - custom lock screen for Android (Vivo Z1 Pro)

BUILD OPTION A - Android Studio (PC)
 1. File > Open > select this MyLock folder, let Gradle sync.
 2. Build > Build APK(s). Copy app-debug.apk to the phone and install.

BUILD OPTION B - from a phone browser (GitHub, free)
 1. Create a new GitHub repository and upload everything in this folder
    (keep the .github folder).
 2. Open the Actions tab > "Build APK" > Run workflow.
 3. When it finishes, download the MyLock-apk artifact, unzip, install app-debug.apk.

SETUP ON THE PHONE
 1. Open My Lock, tap "Allow display over other apps" and enable it.
 2. Tap "Turn lock screen on". Allow notifications.
 3. Allow Auto-start / Background running for My Lock (Vivo battery settings).
 4. Optional: keep your PIN in Settings > Fingerprint and password. Swiping up
    will then ask for it. Set "None" if you want a plain swipe.

APP PIN / PATTERN
 - Open My Lock > Set PIN (4-8 digits) or Set pattern (at least 4 dots).
 - Swiping up on the lock screen then asks for it. 5 wrong tries = 30 second wait.
 - If the phone also has its own PIN, "Use phone PIN instead" appears as a backup.
 - Do not forget the code. With a code set, Home/Back return to the lock screen.
