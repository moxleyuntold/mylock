package com.mylock.screen;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.Toast;

/** Set, change or remove the PIN / pattern. Asks for the current one first. */
public class SetupLockActivity extends Activity {
    private String mode, newType, first;
    private int stage; // 0 verify current, 1 enter new, 2 confirm new
    private AuthLayout auth;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        mode = getIntent().getStringExtra("mode");
        if (mode == null) mode = "pin";
        newType = mode.equals("pattern") ? LockStore.PATTERN : LockStore.PIN;

        FrameLayout root = new FrameLayout(this);
        root.setBackground(Ui.screenBackground());
        auth = new AuthLayout(this);
        auth.addLink("Cancel", v -> finish());
        root.addView(auth, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT,
                Gravity.CENTER));
        setContentView(root);

        boolean has = !LockStore.NONE.equals(LockStore.type(this));
        if (!has && mode.equals("remove")) { finish(); return; }
        stage = has ? 0 : 1;
        show();
    }

    private void show() {
        String type = stage == 0 ? LockStore.type(this) : newType;
        boolean pin = type.equals(LockStore.PIN);
        String what = pin ? "PIN" : "pattern";
        if (stage == 0) {
            auth.setTitle("Current " + what);
            auth.setMessage(mode.equals("remove") ? "Enter it to remove the lock" : "Enter it to continue", false);
        } else if (stage == 1) {
            auth.setTitle("New " + what);
            auth.setMessage(pin ? "Choose 4 to 8 digits, then confirm" : "Connect at least 4 dots", false);
        } else {
            auth.setTitle("Confirm " + what);
            auth.setMessage(pin ? "Enter the same PIN again" : "Draw the same pattern again", false);
        }
        auth.setInput(LockUi.create(this, type, this::onCode));
    }

    private void onCode(String code) {
        boolean pin = (stage == 0 ? LockStore.type(this) : newType).equals(LockStore.PIN);
        CodeInput in = auth.input();
        if (code == null) {
            auth.setMessage(pin ? "Use at least 4 digits" : "Connect at least 4 dots", true);
            in.error();
            return;
        }
        if (stage == 0) {
            if (LockStore.check(this, code)) {
                if (mode.equals("remove")) {
                    LockStore.clear(this);
                    Toast.makeText(this, "Lock removed", Toast.LENGTH_SHORT).show();
                    finish();
                    return;
                }
                stage = 1;
                show();
            } else {
                auth.setMessage(pin ? "Wrong PIN" : "Wrong pattern", true);
                in.error();
            }
        } else if (stage == 1) {
            first = code;
            stage = 2;
            show();
        } else {
            if (code.equals(first)) {
                LockStore.set(this, newType, code);
                Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                stage = 1;
                show();
                auth.setMessage("Did not match. Try again.", true);
            }
        }
    }
}
