plugins { id("com.android.application") }
android {
    namespace = "com.mylock.screen"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.mylock.screen"
        minSdk = 27
        targetSdk = 33
        versionCode = 2
        versionName = "2.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildTypes { release { isMinifyEnabled = false } }
}
