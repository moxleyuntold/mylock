package com.mylock.screen;

import android.content.Context;

final class LockUi {
    private LockUi() { }

    static int dp(Context c, int v) { return (int) (v * c.getResources().getDisplayMetrics().density); }

    static CodeInput create(Context c, String type, CodeInput.OnCode cb) {
        return LockStore.PATTERN.equals(type) ? new PatternView(c, cb) : new PinInput(c, cb);
    }
}
