package com.mylock.screen;

import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Frosted keypad: 4 to 8 digits, confirm with the check key. */
public class PinInput extends LinearLayout implements CodeInput {
    private final StringBuilder sb = new StringBuilder();
    private final PinDots dots;
    private final OnCode cb;

    public PinInput(Context c, OnCode cb) {
        super(c);
        this.cb = cb;
        setOrientation(VERTICAL);
        setGravity(Gravity.CENTER_HORIZONTAL);

        dots = new PinDots(c);
        LayoutParams dp = new LayoutParams(Ui.dp(c, 260), Ui.dp(c, 28));
        dp.bottomMargin = Ui.dp(c, 18);
        addView(dots, dp);

        String[] keys = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "back", "0", "ok"};
        for (int r = 0; r < 4; r++) {
            LinearLayout row = new LinearLayout(c);
            row.setGravity(Gravity.CENTER);
            for (int k = 0; k < 3; k++) {
                row.addView(key(c, keys[r * 3 + k]));
            }
            addView(row);
        }
    }

    private View key(Context c, final String key) {
        int size = Ui.dp(c, 74);
        FrameLayout f = new FrameLayout(c);
        View face;
        if (key.equals("back") || key.equals("ok")) {
            ImageView iv = new ImageView(c);
            iv.setImageResource(key.equals("ok") ? R.drawable.ic_check : R.drawable.ic_backspace);
            iv.setColorFilter(key.equals("ok") ? Theme.ACCENT : Theme.TEXT);
            iv.setScaleType(ImageView.ScaleType.CENTER);
            face = iv;
        } else {
            TextView t = Ui.label(c, 27, Theme.TEXT, false, "sans-serif-light");
            t.setText(key);
            face = t;
        }
        f.addView(face, new FrameLayout.LayoutParams(size, size, Gravity.CENTER));
        f.setBackground(key.equals("ok") ? Ui.accentKey(c) : Ui.glassKey(c));
        f.setClickable(true);
        f.setOnClickListener(v -> press(v, key));
        Ui.pressable(f);
        LayoutParams lp = new LayoutParams(size, size);
        lp.setMargins(Ui.dp(c, 9), Ui.dp(c, 7), Ui.dp(c, 9), Ui.dp(c, 7));
        f.setLayoutParams(lp);
        return f;
    }

    private void press(View v, String key) {
        v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
        if (key.equals("back")) {
            if (sb.length() > 0) sb.deleteCharAt(sb.length() - 1);
        } else if (key.equals("ok")) {
            cb.onCode(sb.length() >= 4 ? sb.toString() : null);
            return;
        } else if (sb.length() < 8) {
            sb.append(key);
        }
        dots.setCount(sb.length());
    }

    @Override public View getView() { return this; }

    @Override public void reset() { sb.setLength(0); dots.setCount(0); }

    @Override public void error() {
        reset();
        dots.setWarn(true);
        Ui.shake(dots);
        dots.postDelayed(() -> dots.setWarn(false), 380);
    }
}
