package com.mylock.screen;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private SharedPreferences sp;
    private TextView status, lockStatus, toggle;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("prefs", Context.MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }

        int pad = Ui.dp(this, 24);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(pad, Ui.dp(this, 48), pad, pad);

        TextView title = left(Ui.label(this, 34, Theme.TEXT, false, "sans-serif-light"));
        title.setText("My Lock");
        col.addView(title);

        TextView sub = left(Ui.label(this, 14, Theme.MUTED, false, "sans-serif"));
        sub.setText("Depth clock lock screen");
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        sl.topMargin = Ui.dp(this, 6);
        col.addView(sub, sl);

        status = left(Ui.label(this, 15, Theme.TEXT, false, "sans-serif-medium"));
        status.setBackground(Ui.glassPill(this));
        status.setPadding(Ui.dp(this, 22), Ui.dp(this, 18), Ui.dp(this, 22), Ui.dp(this, 18));
        LinearLayout.LayoutParams stl = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        stl.topMargin = Ui.dp(this, 28);
        col.addView(status, stl);

        col.addView(section("Setup"));
        col.addView(pill("Allow display over other apps", false, v -> openOverlaySettings()));
        toggle = pill("", true, v -> {
            if (!Settings.canDrawOverlays(this)) { openOverlaySettings(); return; }
            boolean on = !sp.getBoolean("on", false);
            sp.edit().putBoolean("on", on).apply();
            Intent svc = new Intent(this, LockService.class);
            if (on) startForegroundService(svc); else stopService(svc);
            refresh();
        });
        col.addView(toggle);

        col.addView(section("Security"));
        lockStatus = left(Ui.label(this, 14, Theme.MUTED, false, "sans-serif"));
        col.addView(lockStatus);
        col.addView(pill("Set PIN", false, v -> openSetup("pin")));
        col.addView(pill("Set pattern", false, v -> openSetup("pattern")));
        col.addView(pill("Remove PIN / pattern", false, v -> openSetup("remove")));

        col.addView(section("More"));
        col.addView(pill("Preview lock screen", false, v -> LockService.showLock(this)));
        col.addView(pill("Battery: keep running", false, v ->
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))));

        TextView tip = left(Ui.label(this, 13, Theme.MUTED, false, "sans-serif"));
        tip.setText("Vivo: also allow Auto-start and Background running for My Lock in "
                + "Settings > Apps > My Lock, or the lock screen may stop after a while.");
        tip.setLineSpacing(0, 1.15f);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tl.topMargin = Ui.dp(this, 28);
        col.addView(tip, tl);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setBackground(Ui.screenBackground());
        sv.addView(col);
        setContentView(sv);
    }

    private TextView left(TextView t) {
        t.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        return t;
    }

    private TextView section(String s) {
        TextView t = left(Ui.label(this, 12, Theme.ACCENT, true, "sans-serif-medium"));
        t.setLetterSpacing(0.22f);
        t.setText(s);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, 30);
        lp.bottomMargin = Ui.dp(this, 4);
        t.setLayoutParams(lp);
        return t;
    }

    private TextView pill(String text, boolean accent, View.OnClickListener l) {
        TextView t = Ui.label(this, 15, accent ? 0xFF06181A : Theme.TEXT, false, "sans-serif-medium");
        t.setText(text);
        t.setBackground(accent ? Ui.accentPill(this) : Ui.glassPill(this));
        t.setClickable(true);
        t.setOnClickListener(l);
        Ui.pressable(t);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this, 52));
        lp.topMargin = Ui.dp(this, 10);
        t.setLayoutParams(lp);
        return t;
    }

    private void openSetup(String mode) {
        startActivity(new Intent(this, SetupLockActivity.class).putExtra("mode", mode));
    }

    private void openOverlaySettings() {
        startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName())));
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    private void refresh() {
        boolean can = Settings.canDrawOverlays(this);
        boolean on = sp.getBoolean("on", false);
        status.setText(!can ? "Step 1: allow display over other apps."
                : on ? "Lock screen is ON. Turn the screen off and on to see it."
                : "Ready. Turn on the lock screen below.");
        status.setTextColor(on && can ? Theme.ACCENT : Theme.TEXT);
        String t = LockStore.type(this);
        lockStatus.setText("App lock: " + (t.equals(LockStore.PIN) ? "PIN"
                : t.equals(LockStore.PATTERN) ? "Pattern" : "Off"));
        toggle.setText(on ? "Turn lock screen off" : "Turn lock screen on");
    }
}
