package com.mylock.screen;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        boolean on = c.getSharedPreferences("prefs", Context.MODE_PRIVATE).getBoolean("on", false);
        if (on && Settings.canDrawOverlays(c)) {
            c.startForegroundService(new Intent(c, LockService.class));
        }
    }
}
