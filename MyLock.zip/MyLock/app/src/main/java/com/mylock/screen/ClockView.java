package com.mylock.screen;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;

/**
 * Draws one piece of the clock. Everything is drawn from the same centre line, so all
 * text is aligned. The view only redraws when its text changes (once a minute) and is
 * cached on the GPU, which keeps animation smooth and battery use low.
 */
final class ClockView extends View {
    static final int HOUR = 0, MIN = 1, INFO = 2;

    private final int kind;
    private String text = "";
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Rect r = new Rect();

    ClockView(Context c, int kind) {
        super(c);
        this.kind = kind;
        setLayerType(LAYER_TYPE_HARDWARE, null);
    }

    void setText(String t) {
        if (t.equals(text)) return;
        text = t;
        invalidate();
    }

    private void bigDigits(int w, float capH, float widthFrac) {
        p.reset();
        p.setAntiAlias(true);
        p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        p.setTextScaleX(0.74f);
        p.setTextSize(100f);
        p.getTextBounds("0", 0, 1, r);
        float size = 100f * capH / r.height();
        p.setTextSize(size);
        float width = p.measureText(text);
        float maxW = w * widthFrac;
        if (width > maxW) {
            size *= maxW / width;
            p.setTextSize(size);
        }
    }

    @Override protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (text.isEmpty() || w == 0) return;
        switch (kind) {
            case HOUR: drawHour(c, w, h); break;
            case MIN: drawMinutes(c, w, h); break;
            default: drawInfo(c, w, h); break;
        }
    }

    /** Large glossy hour with a 3D extrusion. It sits behind the character. */
    private void drawHour(Canvas c, int w, int h) {
        bigDigits(w, h * 0.31f, 0.92f);
        float size = p.getTextSize();
        p.getTextBounds(text, 0, text.length(), r);
        float x = (w - p.measureText(text)) / 2f;
        float top = h * 0.27f;
        float base = top - r.top;

        // extrusion (down and to the right), far layers darker
        float depth = size * 0.05f;
        p.setStyle(Paint.Style.FILL_AND_STROKE);
        p.setStrokeWidth(size * 0.02f);
        p.setStrokeJoin(Paint.Join.ROUND);
        int steps = Math.max(2, Math.round(depth / 2f));
        for (int i = steps; i >= 1; i--) {
            float t = i / (float) steps;
            p.setShader(null);
            p.setColor(lerp(0xFFB4BDCD, 0xFF4E586C, t));
            float o = depth * t;
            c.drawText(text, x + o * 0.6f, base + o, p);
        }

        // glossy face: bright top, sharp "horizon", cooler bottom
        p.setShader(new LinearGradient(0, top, 0, top + r.height(),
                new int[]{0xFFFFFFFF, 0xFFF3F6FA, 0xFFD9E0EA, 0xFFBFC9D8},
                new float[]{0f, 0.5f, 0.52f, 1f}, Shader.TileMode.CLAMP));
        c.drawText(text, x, base, p);
        p.setShader(null);
    }

    /** Outlined minutes, drawn in front of the character. */
    private void drawMinutes(Canvas c, int w, int h) {
        bigDigits(w, h * 0.16f, 0.66f);
        float size = p.getTextSize();
        p.getTextBounds(text, 0, text.length(), r);
        float x = (w - p.measureText(text)) / 2f;
        float base = h * 0.695f - r.top;
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.argb(30, 255, 255, 255));
        c.drawText(text, x, base, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Ui.dp(getContext(), 1.6f));
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setColor(Color.argb(235, 255, 255, 255));
        c.drawText(text, x, base, p);
    }

    /** Date and battery line, centred above the hour. */
    private void drawInfo(Canvas c, int w, int h) {
        p.reset();
        p.setAntiAlias(true);
        p.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        p.setTextSize(Ui.sp(getContext(), 13f));
        p.setLetterSpacing(0.22f);
        p.setColor(Color.argb(235, 244, 246, 248));
        float width = p.measureText(text);
        float trailing = 0.22f * p.getTextSize(); // spacing added after the last letter
        float x = (w - (width - trailing)) / 2f;
        c.drawText(text, x, h * 0.215f, p);
    }

    private static int lerp(int a, int b, float t) {
        int ar = Color.red(a), ag = Color.green(a), ab = Color.blue(a);
        int br = Color.red(b), bg = Color.green(b), bb = Color.blue(b);
        return Color.rgb((int) (ar + (br - ar) * t), (int) (ag + (bg - ag) * t), (int) (ab + (bb - ab) * t));
    }
}
