package com.mylock.screen;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;
import java.security.MessageDigest;
import java.security.SecureRandom;

/** Stores only a salted hash of the PIN / pattern, never the code itself. */
final class LockStore {
    static final String NONE = "", PIN = "pin", PATTERN = "pattern";

    private LockStore() { }

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("prefs", Context.MODE_PRIVATE);
    }

    static String type(Context c) { return sp(c).getString("lock_type", NONE); }

    static void set(Context c, String type, String code) {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        String s = Base64.encodeToString(salt, Base64.NO_WRAP);
        sp(c).edit().putString("lock_type", type).putString("lock_salt", s)
                .putString("lock_hash", hash(s, code)).apply();
    }

    static boolean check(Context c, String code) {
        String s = sp(c).getString("lock_salt", "");
        return hash(s, code).equals(sp(c).getString("lock_hash", ""));
    }

    static void clear(Context c) {
        sp(c).edit().remove("lock_type").remove("lock_salt").remove("lock_hash").apply();
    }

    private static String hash(String salt, String code) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return Base64.encodeToString((md.digest((salt + ":" + code).getBytes("UTF-8"))), Base64.NO_WRAP);
        } catch (Exception e) { throw new RuntimeException(e); }
    }
}
