package com.mylock.screen;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

/** Decodes the two wallpaper layers once and keeps them, so the lock screen opens instantly. */
final class Art {
    private static Bitmap bg, subject;

    private Art() { }

    static synchronized void load(Context c) {
        if (bg != null && subject != null) return;
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inScaled = false;
        o.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Resources r = c.getApplicationContext().getResources();
        bg = BitmapFactory.decodeResource(r, R.drawable.wall_bg, o);
        subject = BitmapFactory.decodeResource(r, R.drawable.wall_subject, o);
    }

    static synchronized Bitmap bg(Context c) { load(c); return bg; }

    static synchronized Bitmap subject(Context c) { load(c); return subject; }
}
