package com.mylock.screen;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Set, change or remove the PIN / pattern. Asks for the current one first. */
public class SetupLockActivity extends Activity {
    private String mode, newType, first;
    private int stage; // 0 verify current, 1 enter new, 2 confirm new
    private TextView title, msg;
    private FrameLayout holder;
    private CodeInput input;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        mode = getIntent().getStringExtra("mode");
        if (mode == null) mode = "pin";
        newType = mode.equals("pattern") ? LockStore.PATTERN : LockStore.PIN;

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setBackgroundColor(Color.BLACK);
        col.setPadding(0, LockUi.dp(this, 56), 0, LockUi.dp(this, 24));

        title = new TextView(this);
        title.setTextColor(Color.parseColor("#F3ECE6"));
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);
        col.addView(title);

        msg = new TextView(this);
        msg.setTextColor(Color.parseColor("#E5261F"));
        msg.setTextSize(14);
        msg.setGravity(Gravity.CENTER);
        msg.setPadding(0, LockUi.dp(this, 8), 0, LockUi.dp(this, 16));
        col.addView(msg);

        holder = new FrameLayout(this);
        col.addView(holder, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView cancel = new TextView(this);
        cancel.setText("Cancel");
        cancel.setTextColor(Color.parseColor("#99F3ECE6"));
        cancel.setTextSize(16);
        cancel.setPadding(LockUi.dp(this, 24), LockUi.dp(this, 20), LockUi.dp(this, 24), LockUi.dp(this, 20));
        cancel.setOnClickListener(v -> finish());
        col.addView(cancel);
        setContentView(col);

        boolean has = !LockStore.NONE.equals(LockStore.type(this));
        if (!has && mode.equals("remove")) { finish(); return; }
        stage = has ? 0 : 1;
        show();
    }

    private void show() {
        String type;
        if (stage == 0) {
            type = LockStore.type(this);
            title.setText(type.equals(LockStore.PIN) ? "Enter current PIN" : "Draw current pattern");
        } else {
            type = newType;
            boolean pin = type.equals(LockStore.PIN);
            title.setText(stage == 1 ? (pin ? "Choose a PIN" : "Draw a new pattern")
                                      : (pin ? "Confirm PIN" : "Draw it again"));
        }
        input = LockUi.create(this, type, this::onCode);
        holder.removeAllViews();
        if (input instanceof PatternView) {
            holder.addView(input.getView(), new FrameLayout.LayoutParams(
                    LockUi.dp(this, 300), LockUi.dp(this, 300), Gravity.CENTER));
        } else {
            holder.addView(input.getView());
        }
    }

    private void onCode(String code) {
        boolean pin = (stage == 0 ? LockStore.type(this) : newType).equals(LockStore.PIN);
        if (code == null) {
            msg.setText(pin ? "Use at least 4 digits" : "Connect at least 4 dots");
            input.reset();
            return;
        }
        msg.setText("");
        if (stage == 0) {
            if (LockStore.check(this, code)) {
                if (mode.equals("remove")) {
                    LockStore.clear(this);
                    Toast.makeText(this, "Lock removed", Toast.LENGTH_SHORT).show();
                    finish();
                    return;
                }
                stage = 1; show();
            } else { msg.setText("Wrong " + (pin ? "PIN" : "pattern")); input.reset(); }
        } else if (stage == 1) {
            first = code; stage = 2; show();
        } else {
            if (code.equals(first)) {
                LockStore.set(this, newType, code);
                Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                msg.setText("Did not match. Try again.");
                stage = 1; show();
            }
        }
    }
}
