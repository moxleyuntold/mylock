package com.mylock.screen;

import android.content.Context;

final class LockUi {
    private LockUi() { }

    static CodeInput create(Context c, String type, CodeInput.OnCode cb) {
        return LockStore.PATTERN.equals(type) ? new PatternView(c, cb) : new PinInput(c, cb);
    }
}
