package com.mylock.screen;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;

/** 3x3 dot grid. Connect at least 4 dots. */
public class PatternView extends View implements CodeInput {
    private final Paint dotP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint lineP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float[] cx = new float[9], cy = new float[9];
    private final ArrayList<Integer> path = new ArrayList<>();
    private final OnCode cb;
    private float fx, fy, cell;
    private boolean drawing;

    public PatternView(Context c, OnCode cb) {
        super(c);
        this.cb = cb;
        dotP.setColor(Color.parseColor("#F3ECE6"));
        ringP.setColor(Color.parseColor("#E5261F"));
        ringP.setStyle(Paint.Style.STROKE);
        ringP.setStrokeWidth(LockUi.dp(c, 2));
        lineP.setColor(Color.parseColor("#E5261F"));
        lineP.setStrokeWidth(LockUi.dp(c, 4));
        lineP.setStrokeCap(Paint.Cap.ROUND);
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        float s = Math.min(w, h);
        cell = s / 3f;
        float ox = (w - s) / 2f, oy = (h - s) / 2f;
        for (int i = 0; i < 9; i++) {
            cx[i] = ox + cell * (i % 3 + 0.5f);
            cy[i] = oy + cell * (i / 3 + 0.5f);
        }
    }

    @Override protected void onDraw(Canvas c) {
        for (int i = 1; i < path.size(); i++) {
            int a = path.get(i - 1), b = path.get(i);
            c.drawLine(cx[a], cy[a], cx[b], cy[b], lineP);
        }
        if (drawing && !path.isEmpty()) {
            int a = path.get(path.size() - 1);
            c.drawLine(cx[a], cy[a], fx, fy, lineP);
        }
        float small = LockUi.dp(getContext(), 6), big = LockUi.dp(getContext(), 24);
        for (int i = 0; i < 9; i++) {
            boolean used = path.contains(i);
            c.drawCircle(cx[i], cy[i], used ? small * 1.6f : small, dotP);
            if (used) c.drawCircle(cx[i], cy[i], big, ringP);
        }
    }

    private int hit(float x, float y) {
        for (int i = 0; i < 9; i++) {
            float dx = x - cx[i], dy = y - cy[i];
            if (dx * dx + dy * dy < (cell * 0.32f) * (cell * 0.32f)) return i;
        }
        return -1;
    }

    private void add(int i) {
        if (i < 0 || path.contains(i)) return;
        if (!path.isEmpty()) {
            int a = path.get(path.size() - 1);
            int dr = i / 3 - a / 3, dc = i % 3 - a % 3;
            if ((Math.abs(dr) == 2 || dr == 0) && (Math.abs(dc) == 2 || dc == 0)) {
                int mid = (a / 3 + dr / 2) * 3 + (a % 3 + dc / 2);
                if (!path.contains(mid)) path.add(mid);
            }
        }
        path.add(i);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        fx = e.getX(); fy = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                getParent().requestDisallowInterceptTouchEvent(true);
                path.clear(); drawing = true; add(hit(fx, fy));
                break;
            case MotionEvent.ACTION_MOVE:
                add(hit(fx, fy));
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                drawing = false;
                if (e.getActionMasked() == MotionEvent.ACTION_UP && !path.isEmpty()) {
                    String code = null;
                    if (path.size() >= 4) {
                        StringBuilder sb = new StringBuilder();
                        for (int p : path) sb.append(p).append('-');
                        code = sb.toString();
                    }
                    cb.onCode(code);
                }
                postDelayed(this::reset, 350);
                break;
        }
        invalidate();
        return true;
    }

    @Override public View getView() { return this; }

    @Override public void reset() { path.clear(); drawing = false; invalidate(); }
}
