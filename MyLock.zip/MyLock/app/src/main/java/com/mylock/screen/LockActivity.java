package com.mylock.screen;

import android.app.Activity;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class LockActivity extends Activity {
    private static int fails = 0;
    private static long lockedUntil = 0;

    private View content;
    private FrameLayout root;
    private ImageButton flashBtn;
    private CameraManager cm;
    private String flashId;
    private boolean torchOn = false;
    private boolean unlocked = false, leaving = false;
    private float downY;

    private FrameLayout panel;
    private CodeInput input;
    private TextView panelMsg;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setShowWhenLocked(true);
        setTurnScreenOn(true);
        setContentView(R.layout.activity_lock);

        root = findViewById(R.id.root);
        content = findViewById(R.id.content);
        flashBtn = findViewById(R.id.flash);

        cm = (CameraManager) getSystemService(CAMERA_SERVICE);
        try {
            for (String id : cm.getCameraIdList()) {
                CameraCharacteristics c = cm.getCameraCharacteristics(id);
                Boolean f = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                if (Boolean.TRUE.equals(f) && facing != null
                        && facing == CameraCharacteristics.LENS_FACING_BACK) { flashId = id; break; }
            }
        } catch (Exception ignored) { }

        cm.registerTorchCallback(new CameraManager.TorchCallback() {
            @Override public void onTorchModeChanged(String id, boolean enabled) {
                if (id.equals(flashId)) { torchOn = enabled; flashBtn.setSelected(enabled); }
            }
        }, null);

        flashBtn.setOnClickListener(v -> toggleTorch());
        findViewById(R.id.cam).setOnClickListener(v -> openCamera());

        root.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downY = e.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float d = Math.max(0, downY - e.getRawY());
                    content.setTranslationY(-d * 0.4f);
                    content.setAlpha(Math.max(0.3f, 1f - d / root.getHeight()));
                    return true;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL: {
                    float d = downY - e.getRawY();
                    content.animate().translationY(0).alpha(1f).setDuration(200).start();
                    if (e.getActionMasked() == MotionEvent.ACTION_UP
                            && d > root.getHeight() * 0.2f) onSwipeUp();
                    return true;
                }
            }
            return false;
        });
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        unlocked = false;
        hideAuth();
    }

    // ---- unlocking -------------------------------------------------------

    private void onSwipeUp() {
        if (LockStore.NONE.equals(LockStore.type(this))) finishUnlock();
        else showAuth();
    }

    private void showAuth() {
        if (panel != null) return;
        final String type = LockStore.type(this);
        final boolean pin = type.equals(LockStore.PIN);

        panel = new FrameLayout(this);
        panel.setBackgroundColor(0xF2000000);
        panel.setClickable(true);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);

        TextView title = new TextView(this);
        title.setText(pin ? "Enter PIN" : "Draw your pattern");
        title.setTextColor(Color.parseColor("#F3ECE6"));
        title.setTextSize(24);
        col.addView(title);

        panelMsg = new TextView(this);
        panelMsg.setTextColor(Color.parseColor("#E5261F"));
        panelMsg.setTextSize(14);
        panelMsg.setGravity(Gravity.CENTER);
        panelMsg.setPadding(0, LockUi.dp(this, 8), 0, LockUi.dp(this, 14));
        col.addView(panelMsg);

        input = LockUi.create(this, type, this::onCode);
        if (input instanceof PatternView) {
            col.addView(input.getView(), new LinearLayout.LayoutParams(
                    LockUi.dp(this, 300), LockUi.dp(this, 300)));
        } else {
            col.addView(input.getView());
        }

        KeyguardManager km = getSystemService(KeyguardManager.class);
        if (km.isKeyguardSecure()) {
            col.addView(link("Use phone PIN instead", v -> systemUnlock()));
        }
        col.addView(link("Cancel", v -> hideAuth()));

        panel.addView(col, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(panel);
        panel.setAlpha(0f);
        panel.animate().alpha(1f).setDuration(180).start();
    }

    private TextView link(String text, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.parseColor("#99F3ECE6"));
        t.setTextSize(15);
        t.setGravity(Gravity.CENTER);
        t.setPadding(LockUi.dp(this, 24), LockUi.dp(this, 14), LockUi.dp(this, 24), LockUi.dp(this, 14));
        t.setOnClickListener(l);
        return t;
    }

    private void hideAuth() {
        if (panel != null) { root.removeView(panel); panel = null; input = null; }
    }

    private void onCode(String code) {
        boolean pin = LockStore.type(this).equals(LockStore.PIN);
        if (code == null) {
            panelMsg.setText(pin ? "Use at least 4 digits" : "Connect at least 4 dots");
            input.reset();
            return;
        }
        long now = SystemClock.elapsedRealtime();
        if (now < lockedUntil) {
            panelMsg.setText("Too many attempts. Try again in " + ((lockedUntil - now + 999) / 1000) + "s");
            input.reset();
            return;
        }
        if (LockStore.check(this, code)) {
            fails = 0;
            finishUnlock();
        } else {
            fails++;
            if (fails >= 5) {
                fails = 0;
                lockedUntil = now + 30000;
                panelMsg.setText("Too many attempts. Wait 30 seconds.");
            } else {
                panelMsg.setText("Wrong " + (pin ? "PIN" : "pattern"));
            }
            input.reset();
        }
    }

    /** Also hands over to the phone's own lock if one is set. */
    private void finishUnlock() {
        KeyguardManager km = getSystemService(KeyguardManager.class);
        if (km.isKeyguardLocked()) {
            km.requestDismissKeyguard(this, new KeyguardManager.KeyguardDismissCallback() {
                @Override public void onDismissSucceeded() { unlocked = true; finish(); }
                @Override public void onDismissCancelled() { hideAuth(); }
            });
        } else {
            unlocked = true;
            finish();
        }
    }

    private void systemUnlock() { finishUnlock(); }

    // ---- shortcuts -------------------------------------------------------

    private void toggleTorch() {
        if (flashId == null) {
            Toast.makeText(this, "No flash found", Toast.LENGTH_SHORT).show();
            return;
        }
        try { cm.setTorchMode(flashId, !torchOn); } catch (Exception e) {
            Toast.makeText(this, "Flash unavailable", Toast.LENGTH_SHORT).show();
        }
    }

    private void openCamera() {
        KeyguardManager km = getSystemService(KeyguardManager.class);
        String action = km.isKeyguardSecure()
                ? MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA_SECURE
                : MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA;
        leaving = true;
        try {
            startActivity(new Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            try {
                startActivity(new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Exception e2) {
                leaving = false;
                Toast.makeText(this, "Camera app not found", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // ---- lifecycle -------------------------------------------------------

    @Override protected void onResume() {
        super.onResume();
        leaving = false;
        content.setTranslationY(0);
        content.setAlpha(1f);
    }

    /** With an app PIN/pattern set, pressing Home brings the lock screen back. */
    @Override protected void onStop() {
        super.onStop();
        boolean on = getSharedPreferences("prefs", Context.MODE_PRIVATE).getBoolean("on", false);
        if (!unlocked && !leaving && !isFinishing() && on
                && !LockStore.NONE.equals(LockStore.type(this))) {
            LockService.showLock(this);
        }
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    @Override public void onBackPressed() { hideAuth(); }
}
