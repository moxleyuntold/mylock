package com.mylock.screen;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;

/** 3x3 glass-ring grid. Connect at least 4 dots. */
public class PatternView extends View implements CodeInput {
    private final Paint fillP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint lineP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float[] cx = new float[9], cy = new float[9];
    private final ArrayList<Integer> path = new ArrayList<>();
    private final OnCode cb;
    private final Runnable clear = this::reset;
    private float fx, fy, cell;
    private boolean drawing, err;

    public PatternView(Context c, OnCode cb) {
        super(c);
        this.cb = cb;
        ringP.setStyle(Paint.Style.STROKE);
        ringP.setStrokeWidth(Ui.dp(c, 1.3f));
        lineP.setStrokeCap(Paint.Cap.ROUND);
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        float s = Math.min(w, h);
        cell = s / 3f;
        float ox = (w - s) / 2f, oy = (h - s) / 2f;
        for (int i = 0; i < 9; i++) {
            cx[i] = ox + cell * (i % 3 + 0.5f);
            cy[i] = oy + cell * (i / 3 + 0.5f);
        }
    }

    private void line(Canvas c, float x1, float y1, float x2, float y2, int col) {
        // soft glow made of three passes (cheap, works with hardware drawing)
        lineP.setColor(col); lineP.setAlpha(28); lineP.setStrokeWidth(Ui.dp(getContext(), 14));
        c.drawLine(x1, y1, x2, y2, lineP);
        lineP.setColor(col); lineP.setAlpha(70); lineP.setStrokeWidth(Ui.dp(getContext(), 7));
        c.drawLine(x1, y1, x2, y2, lineP);
        lineP.setColor(col); lineP.setAlpha(235); lineP.setStrokeWidth(Ui.dp(getContext(), 2.6f));
        c.drawLine(x1, y1, x2, y2, lineP);
    }

    @Override protected void onDraw(Canvas c) {
        Context ctx = getContext();
        int col = err ? Theme.WARN : Theme.ACCENT;
        for (int i = 1; i < path.size(); i++) {
            int a = path.get(i - 1), b = path.get(i);
            line(c, cx[a], cy[a], cx[b], cy[b], col);
        }
        if (drawing && !path.isEmpty()) {
            int a = path.get(path.size() - 1);
            line(c, cx[a], cy[a], fx, fy, col);
        }
        for (int i = 0; i < 9; i++) {
            if (path.contains(i)) {
                fillP.setColor(col); fillP.setAlpha(26);
                c.drawCircle(cx[i], cy[i], Ui.dp(ctx, 34), fillP);
                fillP.setColor(col); fillP.setAlpha(60);
                c.drawCircle(cx[i], cy[i], Ui.dp(ctx, 24), fillP);
                fillP.setColor(col); fillP.setAlpha(255);
                c.drawCircle(cx[i], cy[i], Ui.dp(ctx, 9), fillP);
            } else {
                ringP.setColor(Theme.TEXT); ringP.setAlpha(80);
                c.drawCircle(cx[i], cy[i], Ui.dp(ctx, 21), ringP);
                fillP.setColor(Theme.TEXT); fillP.setAlpha(150);
                c.drawCircle(cx[i], cy[i], Ui.dp(ctx, 3.5f), fillP);
            }
        }
    }

    private int hit(float x, float y) {
        for (int i = 0; i < 9; i++) {
            float dx = x - cx[i], dy = y - cy[i];
            if (dx * dx + dy * dy < (cell * 0.32f) * (cell * 0.32f)) return i;
        }
        return -1;
    }

    private void add(int i) {
        if (i < 0 || path.contains(i)) return;
        if (!path.isEmpty()) {
            int a = path.get(path.size() - 1);
            int dr = i / 3 - a / 3, dc = i % 3 - a % 3;
            if ((Math.abs(dr) == 2 || dr == 0) && (Math.abs(dc) == 2 || dc == 0)) {
                int mid = (a / 3 + dr / 2) * 3 + (a % 3 + dc / 2);
                if (!path.contains(mid)) path.add(mid);
            }
        }
        path.add(i);
        performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        fx = e.getX(); fy = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                removeCallbacks(clear);
                getParent().requestDisallowInterceptTouchEvent(true);
                path.clear(); err = false; drawing = true;
                add(hit(fx, fy));
                break;
            case MotionEvent.ACTION_MOVE:
                add(hit(fx, fy));
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                drawing = false;
                if (e.getActionMasked() == MotionEvent.ACTION_UP && !path.isEmpty()) {
                    String code = null;
                    if (path.size() >= 4) {
                        StringBuilder sb = new StringBuilder();
                        for (int p : path) sb.append(p).append('-');
                        code = sb.toString();
                    }
                    cb.onCode(code);
                }
                postDelayed(clear, 380);
                break;
        }
        invalidate();
        return true;
    }

    @Override public View getView() { return this; }

    @Override public void reset() { path.clear(); drawing = false; err = false; invalidate(); }

    @Override public void error() { err = true; invalidate(); }
}
