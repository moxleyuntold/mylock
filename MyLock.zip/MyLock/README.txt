MY LOCK v2 - depth-clock lock screen for Android (Vivo Z1 Pro)

IMPORTANT: uninstall the old My Lock app first (GitHub builds are signed with a new
key each time, so Android will refuse to update over the old one).

BUILD FROM A PHONE (GitHub Actions)
 1. In your GitHub repo, upload the new MyLock.zip (same name replaces the old one).
 2. Actions > Build APK > Run workflow. Download the MyLock-apk artifact, extract it,
    install app-debug.apk.

SETUP
 1. Open My Lock > Allow display over other apps.
 2. Turn lock screen on. Allow notifications.
 3. Set PIN or pattern (optional).
 4. Vivo: allow Auto-start and Background running, battery = Unrestricted.
